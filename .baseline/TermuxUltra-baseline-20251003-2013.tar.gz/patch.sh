chmod +x ~/Termux-Ultra/patch.sh
./patch.sh
