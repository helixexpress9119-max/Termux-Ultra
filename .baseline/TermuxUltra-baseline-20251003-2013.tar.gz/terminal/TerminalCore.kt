package com.example.terminal; object TerminalCore { fun runCommand(cmd: String) = "(stub) $cmd" }
