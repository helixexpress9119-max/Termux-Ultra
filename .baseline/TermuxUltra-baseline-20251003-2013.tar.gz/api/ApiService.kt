package com.example.api; object ApiService { fun batteryStatus()="{\"battery\":\"100%\"}" }
