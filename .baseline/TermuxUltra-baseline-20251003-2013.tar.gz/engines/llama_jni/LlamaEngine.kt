package com.example.engines.llama; object LlamaEngine { external fun llamaInfer(prompt: String): String }
