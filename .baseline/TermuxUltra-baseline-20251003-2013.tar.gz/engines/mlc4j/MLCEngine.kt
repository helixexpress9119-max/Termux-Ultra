package com.example.engines.mlc4j; object MLCEngine { external fun mlcInfer(prompt: String): String }
